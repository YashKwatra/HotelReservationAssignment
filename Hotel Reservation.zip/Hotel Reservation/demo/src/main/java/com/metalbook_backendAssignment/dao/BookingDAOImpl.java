package com.metalbook_backendAssignment.dao;

import com.metalbook_backendAssignment.entity.Booking;
import com.metalbook_backendAssignment.repository.BookingRepository;
import com.metalbook_backendAssignment.utils.RoomCategory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public class BookingDAOImpl implements BookingDAO {

    private final BookingRepository bookingRepository;

    @Autowired
    public BookingDAOImpl(BookingRepository bookingRepository) {
        this.bookingRepository = bookingRepository;
    }

    @Override
    public Booking save(Booking booking) {
        return bookingRepository.save(booking);
    }

    @Override
    public Optional<Booking> findById(Long id) {
        return bookingRepository.findById(id);
    }

    @Override
    public List<Booking> findAll() {
        return bookingRepository.findAll();
    }

    @Override
    public long countByCategory(RoomCategory category) {
        return bookingRepository.countByCategory(category);
    }
}
