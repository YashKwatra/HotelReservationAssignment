package com.metalbook_backendAssignment.dao;

import com.metalbook_backendAssignment.entity.Booking;
import com.metalbook_backendAssignment.utils.RoomCategory;
import java.util.List;
import java.util.Optional;

public interface BookingDAO {
    Booking save(Booking booking);
    Optional<Booking> findById(Long id);
    List<Booking> findAll();
    long countByCategory(RoomCategory category);
}
