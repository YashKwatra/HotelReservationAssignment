package com.metalbook_backendAssignment.exception;

public class RoomNotAvailableException extends Exception {
    public RoomNotAvailableException() {
        super();
    }

    public RoomNotAvailableException(String message) {
        super(message);
    }

    public RoomNotAvailableException(String message, Throwable cause) {
        super(message, cause);
    }
}
