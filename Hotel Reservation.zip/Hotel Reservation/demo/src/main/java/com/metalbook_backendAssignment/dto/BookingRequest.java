package com.metalbook_backendAssignment.dto;

import com.metalbook_backendAssignment.utils.RoomCategory;
import lombok.Data;

import java.awt.print.Book;

@Data
public class BookingRequest {
    private Integer guestCount;

    private Boolean includeBreakfast;
    private Boolean includeExcursion;

    private RoomCategory roomCategory;

    private String customerName;
}
