package com.metalbook_backendAssignment.utils;

public enum RoomCategory {
    DELUXE, LUXURY
}
