package com.metalbook_backendAssignment.service;

import com.metalbook_backendAssignment.dao.BookingDAO;
import com.metalbook_backendAssignment.dto.BookingRequest;
import com.metalbook_backendAssignment.entity.Booking;
import com.metalbook_backendAssignment.exception.RoomNotAvailableException;
import com.metalbook_backendAssignment.repository.BookingRepository;
import com.metalbook_backendAssignment.utils.RoomCategory;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.time.ZonedDateTime;

@Slf4j
@Service
public class BookingService {
    private final BookingRepository bookingRepository;

    private final BookingDAO bookingDAO;
    @Value("${MAX_DELUXE_ROOMS}")
    private  int maxDeluxeRooms;

    @Value("${MAX_LUXURY_ROOMS}")
    private int maxLuxuryRooms ;

    @Value("${luxuryRoomPrice}")
    private int luxuryRoomPrice;

    @Value("${deluxeRoomPrice}")
    private int deluxeRoomPrice;
    @Value("${breakFastCost}")
    private int breakFastCost;

    @Value("${excursionCost}")
    private int excusionPrice;



    @Autowired
    public BookingService(BookingRepository bookingRepository, BookingDAO bookingDAO) {
        this.bookingRepository = bookingRepository;
        this.bookingDAO = bookingDAO;
    }

    public Booking createBooking(BookingRequest request) throws RoomNotAvailableException {
        log.info("Inside  createBooking");
        if (!isRoomAvailable(request.getRoomCategory())) {
            throw new RoomNotAvailableException("No rooms available for category " + request.getRoomCategory());
        }
        double calculatedCost = calculateTotalCost(request);

        Booking booking = new Booking(
                null,
                request.getCustomerName(),
                request.getRoomCategory(),
                request.getGuestCount(),
                request.getIncludeBreakfast(),
                request.getIncludeExcursion(),
                calculatedCost,
                ZonedDateTime.now()
        );

        return bookingDAO.save(booking);
    }

    private boolean isRoomAvailable(RoomCategory roomType) {
        log.info("Inisde isRoomAvailable");
        log.info("Total deluxe rooms {}",maxDeluxeRooms);
        long bookedRooms = bookingDAO.countByCategory(roomType);
        if (roomType == RoomCategory.DELUXE) {
            return bookedRooms < maxDeluxeRooms;
        } else {
            return bookedRooms < maxLuxuryRooms;
        }
    }

    private double calculateTotalCost(BookingRequest request) {
        log.info("Inside calculateTotalCost");
        double roomPrice = (request.getRoomCategory() == RoomCategory.LUXURY) ? luxuryRoomPrice : deluxeRoomPrice;
        double breakfastCost = request.getIncludeBreakfast() ? request.getGuestCount() * breakFastCost : 0;
        double excursionCost = request.getIncludeExcursion() ? request.getGuestCount() *  excusionPrice: 0;
        double totalCost= roomPrice + breakfastCost + excursionCost;
        log.info("Total Cost calculated {}",totalCost);
        return totalCost;
    }
}
