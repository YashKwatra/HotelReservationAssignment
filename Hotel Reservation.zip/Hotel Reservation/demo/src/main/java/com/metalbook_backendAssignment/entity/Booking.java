package com.metalbook_backendAssignment.entity;

import com.metalbook_backendAssignment.utils.RoomCategory;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.ZonedDateTime;

@Entity
@Data
@AllArgsConstructor
@Table(name="Booking")
public class Booking {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long bookingId;

    private String customerName;

    @Enumerated(EnumType.STRING)
    private RoomCategory category;

    private Integer guestCount;
    private Boolean breakfastIncluded;
    private Boolean excursionIncluded;
    private Double totalPrice;

    private ZonedDateTime createdAt;
}
