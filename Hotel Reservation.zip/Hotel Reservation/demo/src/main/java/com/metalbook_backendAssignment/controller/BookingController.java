package com.metalbook_backendAssignment.controller;

import com.metalbook_backendAssignment.dto.BookingRequest;
import com.metalbook_backendAssignment.dto.ReservationResponse;
import com.metalbook_backendAssignment.entity.Booking;
import com.metalbook_backendAssignment.exception.RoomNotAvailableException;
import com.metalbook_backendAssignment.service.BookingService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
public class BookingController {
    private final BookingService bookingService;

    @Autowired
    public BookingController(BookingService bookingService) {
        this.bookingService = bookingService;
    }

    @PostMapping("/createBooking")
    public ResponseEntity<Booking> createBooking( @RequestBody BookingRequest request) {
            Booking booking = null;
            try {
                booking = bookingService.createBooking(request);
            } catch (RoomNotAvailableException e) {
                throw new RuntimeException(e);
            }
            return ResponseEntity.status(HttpStatus.CREATED).body(booking);
        }

}
