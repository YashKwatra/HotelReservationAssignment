package com.metalbook_backendAssignment.repository;

import com.metalbook_backendAssignment.entity.Booking;
import com.metalbook_backendAssignment.utils.RoomCategory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface BookingRepository extends JpaRepository<Booking, Long> {
    long countByCategory(RoomCategory category);
}
