package com.metalbook_backendAssignment.dto;

import lombok.Data;

import java.time.ZonedDateTime;

@Data
public class ReservationResponse {
    private Long reservationId;
    private String category;
    private Integer guestCount;
    private Double totalCost;
    private String breakfastIncluded;
    private String excursionIncluded;
    private ZonedDateTime reservationTime;
}
