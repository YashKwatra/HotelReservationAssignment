package com.metalbook_backendAssignment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MBookAssessmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(MBookAssessmentApplication.class, args);
	}

}
